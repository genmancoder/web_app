<?php

    $servername = "localhost";
    $username = "admin";
    $password = "admin";
    $dbname = "act-5";

    $conn = new mysqli($servername, $username, $password, $dbname);

?>